package ygraph.ai.smartfox;

public @interface Instantiation {

}
