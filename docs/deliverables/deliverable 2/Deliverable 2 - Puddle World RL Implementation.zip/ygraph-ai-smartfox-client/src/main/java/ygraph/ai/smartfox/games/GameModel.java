package ygraph.ai.smartfox.games;

/**
 * For testing purpose only
 * 
 * @author yongg
 *
 */
public class GameModel {
	

}
